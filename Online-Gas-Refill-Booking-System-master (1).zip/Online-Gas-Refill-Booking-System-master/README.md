# Online Gas Refill Booking System

Technologies:
  HTML, CSS, Bootstrap, JavaScript, JQuery, Ajax, PHP and MySQL

Description:
  This full-stack web application which provides an easy interface for consumers, distributors as well as Administrators. By provided credentials, consumers can book new refill and distributor can manage the list of consumers and their orders. Administrators can manage the distributors and can also look at various complaint/feedbacks which are made by consumers
